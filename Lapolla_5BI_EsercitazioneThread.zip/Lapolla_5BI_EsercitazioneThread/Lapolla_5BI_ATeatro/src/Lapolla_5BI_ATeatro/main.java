package Lapolla_5BI_ATeatro;

public class main {
	//La classe main serve a controllare i posti ancora disponibili nel teatro
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
