package Lapolla_5BI_ATeatro;

public class Spettatore {
	
}
