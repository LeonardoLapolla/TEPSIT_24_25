package Lapolla_5BI_StatoDeiThread;
import java.util.Random;
import java.util.random.*;

public class Contatore extends Thread implements Runnable {
	private int val;
	private int cont;
	private boolean Completato = false;
	
	public Contatore(int n) {
		val = n;
		cont = 0;
	}

	public boolean getCont() {
		if(cont == val) {
			if(!Completato) {
				System.out.println("COMPLETATO");
			}
			Completato = true;
			return true;
		}else {
			System.out.println("("+ Thread.currentThread().getId() +")"+ "è arrivato a " +cont);
			return false;
		}
		
	}
	

	
	public void run() {
		for (int i = 0; i < val; i++) {
			cont = cont + 1;
			try {
				Thread.sleep(120);
			}catch (Exception e) {}
		}
	}

}
